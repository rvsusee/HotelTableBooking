package hotel.table.booking.model;

public class TableDetails {
	int tbID;
	int branchID;
	int tbSize;

	public TableDetails(int tbID, int branchID, int tbSize) {
		this.tbID = tbID;
		this.branchID = branchID;
		this.tbSize = tbSize;
	}

	public int getTbID() {
		return tbID;
	}

	public int getBranchID() {
		return branchID;
	}

	public void setBranchID(int branchID) {
		this.branchID = branchID;
	}

	public void setTbID(int tbID) {
		this.tbID = tbID;
	}

	public int getTbSize() {
		return tbSize;
	}

	public void setTbSize(int tbSize) {
		this.tbSize = tbSize;
	}

	@Override
	public String toString() {
		return "TableDetails [tbID=" + tbID + ", branchID=" + branchID + ", tbSize=" + tbSize + "]";
	}

}

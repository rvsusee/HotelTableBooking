package hotel.table.booking.model;

public class UserDetails {
	private int userID;
	private String userName;
	private int userMobileNo;
	private String emailID;

	public UserDetails(int userID, String userName, int userMobileNo, String emailID) {
		this.userID = userID;
		this.userName = userName;
		this.userMobileNo = userMobileNo;
		this.emailID = emailID;
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getUserMobileNo() {
		return userMobileNo;
	}

	public void setUserMobileNo(int userMobileNo) {
		this.userMobileNo = userMobileNo;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	@Override
	public String toString() {
		return "UserDetails [userID=" + userID + ", userName=" + userName + ", userMobileNo=" + userMobileNo
				+ ", emailID=" + emailID + "]";
	}

}

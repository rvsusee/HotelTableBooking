package hotel.table.booking.model;

public class BookedDetails {
	int bkID;
	int bkPersonCount;
	int bkDate;
	int bkTime;
	int bkLog;

	public BookedDetails(int bkID, int bkPersonCount, int bkDate, int bkTime, int bkLog) {
		this.bkID = bkID;
		this.bkPersonCount = bkPersonCount;
		this.bkDate = bkDate;
		this.bkTime = bkTime;
		this.bkLog = bkLog;
	}

	public int getBkID() {
		return bkID;
	}

	public void setBkID(int bkID) {
		this.bkID = bkID;
	}

	public int getBkPersonCount() {
		return bkPersonCount;
	}

	public void setBkPersonCount(int bkPersonCount) {
		this.bkPersonCount = bkPersonCount;
	}

	public int getBkDate() {
		return bkDate;
	}

	public void setBkDate(int bkDate) {
		this.bkDate = bkDate;
	}

	public int getBkTime() {
		return bkTime;
	}

	public void setBkTime(int bkTime) {
		this.bkTime = bkTime;
	}

	public int getBkLog() {
		return bkLog;
	}

	public void setBkLog(int bkLog) {
		this.bkLog = bkLog;
	}

	@Override
	public String toString() {
		return "BookedDetails [bkID=" + bkID + ", bkPersonCount=" + bkPersonCount + ", bkDate=" + bkDate + ", bkTime="
				+ bkTime + ", bkLog=" + bkLog + "]";
	}

}

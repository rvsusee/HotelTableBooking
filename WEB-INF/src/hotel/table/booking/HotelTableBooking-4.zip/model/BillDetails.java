package hotel.table.booking.model;

public class BillDetails {
	private int billId;
	private BookingDetails bookingDetails;
	private double billAmount;

	public BillDetails(int billId, BookingDetails bookingDetails, double billAmount) {
		this.billId = billId;
		this.bookingDetails = bookingDetails;
		this.billAmount = billAmount;
	}

	public int getBillId() {
		return billId;
	}

	public void setBillId(int billId) {
		this.billId = billId;
	}

	public BookingDetails getBookingDetails() {
		return bookingDetails;
	}

	public void setBookingDetails(BookingDetails bookingDetails) {
		this.bookingDetails = bookingDetails;
	}

	public double getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(double billAmount) {
		this.billAmount = billAmount;
	}
}

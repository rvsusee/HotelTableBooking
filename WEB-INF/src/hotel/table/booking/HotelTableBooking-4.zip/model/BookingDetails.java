
package hotel.table.booking.model;

import java.util.Date;

public class BookingDetails {
	private int bookingId;
	private Customer customer;
	private int bookingPersonCount;
	private Date bookingDateTime;
	private TableDetails allocatedTable;
	private Date bookingOn;

	public BookingDetails(int bookingId, Customer customer, int bookingPersonCount, Date bookingDateTime,
			TableDetails allocatedTable, Date bookingOn) {
		this.bookingId = bookingId;
		this.customer = customer;
		this.bookingPersonCount = bookingPersonCount;
		this.bookingDateTime = bookingDateTime;
		this.allocatedTable = allocatedTable;
		this.bookingOn = bookingOn;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public int getBookingPersonCount() {
		return bookingPersonCount;
	}

	public void setBookingPersonCount(int bookingPersonCount) {
		this.bookingPersonCount = bookingPersonCount;
	}

	public Date getBookingDateTime() {
		return bookingDateTime;
	}

	public void setBookingDateTime(Date bookingDateTime) {
		this.bookingDateTime = bookingDateTime;
	}

	public TableDetails getAllocatedTable() {
		return allocatedTable;
	}

	public void setAllocatedTable(TableDetails allocatedTable) {
		this.allocatedTable = allocatedTable;
	}

	public Date getBookingOn() {
		return bookingOn;
	}

	public void setBookingOn(Date bookingOn) {
		this.bookingOn = bookingOn;
	}

}
